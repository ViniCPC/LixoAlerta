$(document).ready(function () {
    $("#btn").click(function () {
      $("#meuFormulario").show();
      $("#btn").hide();
      $("#btn1").hide();
    });
  });
  
  $(document).ready(function () {
    $("#btn1").click(function () {});
  });
  
  $(document).ready(function () {
    $("btn btn-primary").click(function () {});
  });
  
  const formulario = document.querySelector("form");
  
  formulario.onsubmit = function (e) {
    e.preventDefault();
    const horario = document.getElementById("horario").value;
    const ajudaDia = document.querySelectorAll('[name="ajudaDia"]');
    const opiniaoLixo = document.getElementById("opiniaoLixo").value;
   
    const data = { 
      horario: horario,
      ajudaDiaSim: ajudaDia[0].checked,
      ajudaDiaNao: ajudaDia[1].checked,
      opiniaoLixo: opiniaoLixo
    };
  
    
    localStorage.setItem('opiniaoLixo', JSON.stringify(data))

    window.location.href = 'viaCep.html';

  };
  
  document.addEventListener('DOMContentLoaded', () => {
      const restoreData = localStorage.getItem('opiniaoLixo')
      if(restoreData !== null){
          const resposta = prompt('Seu formulario ja foi enviado, deseja preencher novamente?')
          if(resposta === true) {
              localStorage.removeItem('opiniaoLixo');
          }
      }
  })