const data = new Date();
const dia = String(data.getDate()).padStart(2, '0');
const mes = String(data.getMonth() + 1).padStart(2, '0');
const ano = data.getFullYear();
const dataAtual = `${dia}/${mes}/${ano}`;
const diasDaSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
const diaDaSemana = diasDaSemana[data.getDay()];

document.getElementById("data-atual").textContent = dataAtual;
document.getElementById("dia-da-semana").textContent = diaDaSemana;

function mostrarHorarioAtual() {
    const elementoHorario = document.getElementById('horario');
    const dataAtual = new Date();
    const horarioFormatado = `${dataAtual.getHours()}:${adicionarZero(dataAtual.getMinutes())}:${adicionarZero(dataAtual.getSeconds())}`;
    elementoHorario.textContent = horarioFormatado;
}

function adicionarZero(numero) {
    return numero < 10 ? `0${numero}` : numero;
}

setInterval(mostrarHorarioAtual, 1000);
mostrarHorarioAtual();

let caminhaoLat = -19.9173;
let caminhaoLon = -43.987;
const localDestinoLat = -19.9225;
const localDestinoLon = 43.9925;
const velocidadeKmPerSegundo = 10.1;
let caminhaoChegouAoDestino = false;

function calcularDistancia(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

function verificarDistancia(lat1, lon1, lat2, lon2) {
    const distancia = calcularDistancia(lat1, lon1, lat2, lon2);
    if (distancia < 7.0 && !caminhaoChegouAoDestino) {
        alert("Caminhão está chegando ao destino!");
        caminhaoChegouAoDestino = true;
        setTimeout(function () {
            alert("Caminhão chegou ao destino!");
            window.location.href = 'feedback.html';
        }, 10000);
    }
}

function moverCaminhao() {
    if (caminhaoChegouAoDestino) {
        return;
    }
    const distanciaLat = localDestinoLat - caminhaoLat;
    const distanciaLon = localDestinoLon - caminhaoLon;
    const distanciaTotal = Math.sqrt(distanciaLat * distanciaLat + distanciaLon * distanciaLon);
    if (distanciaTotal < velocidadeKmPerSegundo) {
        caminhaoLat = localDestinoLat;
        caminhaoLon = localDestinoLon;
    } else {
        caminhaoLat += distanciaLat / distanciaTotal * velocidadeKmPerSegundo;
        caminhaoLon += distanciaLon / distanciaTotal * velocidadeKmPerSegundo;
    }
    verificarDistancia(caminhaoLat, caminhaoLon, localDestinoLat, localDestinoLon);
}

setInterval(moverCaminhao, 1000);

function obterParametrosURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('cep');
}

function exibirEnderecoNoHeader() {
    const cep = obterParametrosURL();
    if (cep) {
        buscarEnderecoViaCEP(cep);
    }
}



function buscarEnderecoViaCEP(cep) {
    const url = `https://viacep.com.br/ws/${cep}/json`;
    fetch(url)
        .then(response => response.json())
        .then(dados => {
            if (!dados.erro) {
                const enderecoHeader = document.getElementById('enderecoHeader');
                enderecoHeader.innerHTML = `<p>Seu Endereço é: ${dados.logradouro}, ${dados.bairro}, ${dados.localidade} - ${dados.uf}</p>`;
                buscarCoordenadas(cep); 
            } else {
                console.error('CEP não encontrado.');
            }
        })
        .catch(error => console.error('Erro ao buscar endereço: ', error));
}



window.onload = function() {
    const cep = obterParametrosURL();
    if (cep) {
        exibirEnderecoNoHeader();
    }
    mostrarHorarioAtual(); 
    setInterval(moverCaminhao, 1000); 
};


function buscarCoordenadas(cep) {
    var apiKey = 'AIzaSyDEKCAGVvJ3QcbEWs6KYuZT3RrgnmGrGRg'; 
    var url = `https://maps.googleapis.com/maps/api/geocode/json?address=${cep}&key=${apiKey}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'OK') {
                var lat = data.results[0].geometry.location.lat;
                var lng = data.results[0].geometry.location.lng;

                var linkMapa = document.getElementById('linkMapa');
                linkMapa.href = `mapa.html?lat=${lat}&lng=${lng}`;
                linkMapa.style.display = 'block'; // Torna o botão visível
            } else {
                console.error('Não foi possível obter a localização: ' + data.status);
            }
        })
        .catch(error => console.error('Erro ao buscar coordenadas: ', error));
}



window.onload = function() {
    exibirEnderecoNoHeader();
    const cep = obterParametrosURL();
    if (cep) {
        buscarCoordenadas(cep);
    }
};

window.onload = exibirEnderecoNoHeader;
