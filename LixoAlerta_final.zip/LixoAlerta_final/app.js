const data = new Date()

const dia = String(data.getDate()).padStart(2,'0')

const mes  = String(data.getMonth() + 1).padStart(2,'0')

const ano = data.getFullYear()

const dataAtual = `${dia}/${mes}/${ano}`

const diasDaSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
const diaDaSemana = diasDaSemana[data.getDay()];

// Recupere os elementos pelos ids e insira a data e o dia da semana formatados neles
document.getElementById("data-atual").textContent = dataAtual;
document.getElementById("dia-da-semana").textContent = diaDaSemana;


function mostrarHorarioAtual() {
    const elementoHorario = document.getElementById('horario');
    
    const dataAtual = new Date();
    const hora = dataAtual.getHours();
    const minutos = dataAtual.getMinutes();
    const segundos = dataAtual.getSeconds();
    
    const horarioFormatado = `${hora}:${adicionarZero(minutos)}:${adicionarZero(segundos)}`;
    
    elementoHorario.textContent = horarioFormatado;
  }
  
  function adicionarZero(numero) {
    return numero < 10 ? `0${numero}` : numero;
  }
  
  // Atualizar o horário a cada segundo
  setInterval(mostrarHorarioAtual, 1000);
  
  // Mostrar o horário quando a página carregar
  mostrarHorarioAtual();

let caminhaoLat = -19.9173; // Latitude inicial do caminhão
let caminhaoLon = -43.987; // Longitude inicial do caminhão

const localDestinoLat = -19.9225; // Latitude do local de destino
const localDestinoLon = 43.9925; // Longitude do local de destino

const velocidadeKmPerSegundo = 10.1; // Velocidade simulada em km/s

let caminhaoChegouAoDestino = false; // Variável de controle

function calcularDistancia(lat1, lon1, lat2, lon2) {
    const R = 6371; // Raio médio da Terra em km
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distancia = R * c;
    return distancia;
}

function verificarDistancia(lat1, lon1, lat2, lon2) {
    const distancia = calcularDistancia(lat1, lon1, lat2, lon2);

    if (distancia < 7.0 && !caminhaoChegouAoDestino) {
        alert("Caminhão está chegando ao destino!");
        caminhaoChegouAoDestino = true; // Defina a variável como true para evitar mais alertas
        setTimeout(function () {
            alert("Caminhão chegou ao destino!");
            window.location.href = 'feedback.html';
        }, 10000); // Agende o segundo alerta para ser exibido 5 segundos depois
    }
}

function obterParametrosURL() {
    const urlParams = new URLSearchParams(window.location.search);
    const endereco = {
        logradouro: urlParams.get('logradouro'),
        bairro: urlParams.get('bairro'),
        localidade: urlParams.get('localidade'),
        uf: urlParams.get('uf')
    };
    return endereco;
}

// Função para exibir o endereço no cabeçalho
function exibirEnderecoNoHeader() {
    const endereco = obterParametrosURL();
    const enderecoHeader = document.getElementById('enderecoHeader');
    
    if (endereco) {
        enderecoHeader.innerHTML = `<p>Seu Endereço é: ${endereco.logradouro}, ${endereco.bairro}, ${endereco.localidade} - ${endereco.uf}</p>`;
    } else {
        enderecoHeader.innerHTML = '<p>Endereço não disponível.</p>';
    }
}

// Chama a função ao carregar a página
window.onload = exibirEnderecoNoHeader;

function moverCaminhao() {
    if (caminhaoChegouAoDestino) {
        return; // Se o caminhão já chegou ao destino, não faça mais nada
    }

    const distanciaLat = localDestinoLat - caminhaoLat;
    const distanciaLon = localDestinoLon - caminhaoLon;
    const distanciaTotal = Math.sqrt(distanciaLat * distanciaLat + distanciaLon * distanciaLon);

    const distanciaFormatada = distanciaTotal.toFixed(2); // Formate a distância com 2 casas decimais

    console.log(`Distância atual: ${distanciaFormatada} Metros`);

    if (distanciaTotal < velocidadeKmPerSegundo) {
        caminhaoLat = localDestinoLat;
        caminhaoLon = localDestinoLon;
    } else {
        const direcaoLat = distanciaLat / distanciaTotal;
        const direcaoLon = distanciaLon / distanciaTotal;

        caminhaoLat += direcaoLat * velocidadeKmPerSegundo;
        caminhaoLon += direcaoLon * velocidadeKmPerSegundo;
    }

    verificarDistancia(caminhaoLat, caminhaoLon, localDestinoLat, localDestinoLon);
}

function alertarChegadaAoDestino() {
    if (!caminhaoChegouAoDestino) {
        alert("Caminhão está chegando ao destino!");
        caminhaoChegouAoDestino = true; // Defina a variável como true para evitar mais alertas
        setTimeout(function () {
            const pag = '../../Funcionalidade_feedback'; // Redirecionar para outra página após o alerta
            console.log(pag);
            alert("Caminhão chegou ao destino!");
        }, 5000); // Agendar o segundo alerta para ser exibido 5 segundos depois
    }
}


setInterval(moverCaminhao, 1000); // Mover o caminhão a cada segundo
